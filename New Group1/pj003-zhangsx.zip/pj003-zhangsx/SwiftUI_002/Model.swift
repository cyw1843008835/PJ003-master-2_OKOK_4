//
//  Model.swift
//  SwiftUI_002
//
//  Created by XIAOFEI MA on 2020/01/05.
//  Copyright © 2020 XIAOFEI MA. All rights reserved.
//

import Foundation
struct Model: Decodable {
    let name: String
}
