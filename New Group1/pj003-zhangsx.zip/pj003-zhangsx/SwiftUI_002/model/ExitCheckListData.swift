//
//  ExitCheckListData.swift
//  SwiftUI_002
//
//  Created by IMAC NCJ on 2020/01/14.
//  Copyright © 2020 XIAOFEI MA. All rights reserved.
//

import Foundation

let exitCheckListdata = [
     ExitCheckListItem(id:0,title: "会議室内消灯"),
      ExitCheckListItem(id:1,title: "執務室内消灯"),
       ExitCheckListItem(id:2,title: "電気ボット"),
        ExitCheckListItem(id:3,title: "窓閉め"),
         ExitCheckListItem(id:4,title: "プロジェクター電源OFF")
]

