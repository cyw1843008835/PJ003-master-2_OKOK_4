//
//  PhotoCaptureView.swift
//  SwiftUI_002
//
//  Created by XIAOFEI MA on 2019/12/24.
//  Copyright © 2019 XIAOFEI MA. All rights reserved.
//

import SwiftUI

struct PhotoCaptureView: View {
    @Binding var showImagePicker: Bool
    @Binding var image:Image?
    
    
    var body: some View {
        ImagePicker(isShown: $showImagePicker, image: $image)
    }
}

#if DEBUG
struct PhotoCaptureView_Previews: PreviewProvider {
    static var previews: some View {
        PhotoCaptureView(showImagePicker: .constant(false), image: .constant(Image("")))
    }
}
#endif

