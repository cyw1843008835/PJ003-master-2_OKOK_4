//
//  UserList.swift
//  SwiftUI_002
//
//  Created by XIAOFEI MA on 2020/01/05.
//  Copyright © 2020 XIAOFEI MA. All rights reserved.
//

import Foundation
import Combine
import SwiftUI

class UserList: ObservableObject {
    @Published var mainlist: [Mainlist] = []
    @Published var distlist: [Distlist] = []
    
    @Published var userimg: [Userimg] = []
    
    init() {
        load()
//        post()
    }
    
    func load() {
        let url = URL(string: "http://192.168.10.6:3000/mainlist_v")!
        URLSession.shared.dataTask(with: url) { data, response, error in
            DispatchQueue.main.async {
                self.mainlist = try! JSONDecoder().decode([Mainlist].self, from: data!)
            }
        }.resume()
        let url2 = URL(string: "http://192.168.10.6:3000/distlist_v")!
        URLSession.shared.dataTask(with: url2) { data, response, error in
            DispatchQueue.main.async {
                self.distlist = try! JSONDecoder().decode([Distlist].self, from: data!)
            }
        }.resume()
        
//        let url3 = URL(string: "http://192.168.10.6:3000/testing")!
//        print(url3)
//               URLSession.shared.dataTask(with: url3) { data, response, error in
//                   DispatchQueue.main.async {
//                       self.userimg = try! JSONDecoder().decode([Userimg].self, from: data!)
//                    print(self.userimg[0].userid)
//                    if (self.userimg.count > 0){
//                      let img = self.convertBase64StringToImage(imageBase64String: self.userimg[1].userimg)
//                        print(img?.pngData())
//                    }
//                   }
//               }.resume()
    }
    
    func post(userId:String,userName:String,distCode :String){
        let url = URL(string: "http://192.168.10.7:3000/user_m")
        var request = URLRequest(url: url!)
        // POSTを指定
        request.httpMethod = "POST"
        // POSTするデータをBodyとして設定
        let urlstr = "userid=" + userId + "&username=" + userName + "&distcode=" + distCode
//        request.httpBody = "userid=666666&username=true&distcode=8888".data(using: .utf8)
        request.httpBody = urlstr.data(using: .utf8)!
        let session = URLSession.shared
        session.dataTask(with: request) { (data, response, error) in
            if error == nil, let data = data, let response = response as? HTTPURLResponse {
                // HTTPヘッダの取得
                print("Content-Type: \(response.allHeaderFields["Content-Type"] ?? "")")
                // HTTPステータスコード
                print("statusCode: \(response.statusCode)")
                print(String(data: data, encoding: .utf8) ?? "")
            }
        }.resume()
    }
    func postAdd(userId:String,userName:String,distCode :String,img: Image){
            let url = URL(string: "http://192.168.10.7:3000/user_m")
            var request = URLRequest(url: url!)
            // POSTを指定
            request.httpMethod = "POST"
            // POSTするデータをBodyとして設定
            let urlstr = "userid=" + userId + "&username=" + userName + "&distcode=" + distCode
    //        request.httpBody = "userid=666666&username=true&distcode=8888".data(using: .utf8)
            request.httpBody = urlstr.data(using: .utf8)!
            let session = URLSession.shared
            session.dataTask(with: request) { (data, response, error) in
                if error == nil, let data = data, let response = response as? HTTPURLResponse {
                    // HTTPヘッダの取得
                    print("Content-Type: \(response.allHeaderFields["Content-Type"] ?? "")")
                    // HTTPステータスコード
                    print("statusCode: \(response.statusCode)")
                    print(String(data: data, encoding: .utf8) ?? "")
                }
            }.resume()
        }
    
    func postImg(img: UIImage){
        
//        let base64ImgStr = convertImageToBase64(img)
        let imageData:NSData = img.toJpegData(.min)! as NSData
        
        let base64ImgStr = Utils.base64UrlSafeEncoding(data: imageData as Data)

            
            let url = URL(string: "http://192.168.10.6:3000/testing")
            var request = URLRequest(url: url!)
            // POSTを指定
            request.httpMethod = "POST"
            // POSTするデータをBodyとして設定
            let urlstr = "userid=" + "001872" + "&userimg=" + base64ImgStr
    //        request.httpBody = "userid=666666&username=true&distcode=8888".data(using: .utf8)
            request.httpBody = urlstr.data(using: .utf8)!
            let session = URLSession.shared
            session.dataTask(with: request) { (data, response, error) in
                if error == nil, let data = data, let response = response as? HTTPURLResponse {
                    // HTTPヘッダの取得
                    print("Content-Type: \(response.allHeaderFields["Content-Type"] ?? "")")
                    // HTTPステータスコード
                    print("statusCode: \(response.statusCode)")
                    print(String(data: data, encoding: .utf8) ?? "")
                }
            }.resume()
        }

    func postNeoFaceImg(img: UIImage){
        
        let base64ImgStr = convertImageToBase64(img)
        print(img.size)
        
        let params:[String:Any] = [
            "paramSetId": "AUTH_1_N_M_NONE",
            "queryImages":base64ImgStr
        ]
            
            let url = URL(string: "https://api.cloud.nec.com/neoface/f-face-image/v1/action/auth")
            var request = URLRequest(url: url!)
            // POSTを指定
            request.httpMethod = "POST"
           request.addValue("l70729f43684e243309443593a69487f27", forHTTPHeaderField: "apikey")
        request.addValue("appliation/json; charset=UTF-8", forHTTPHeaderField: "Content-Type")
//        request.addValue(JSONEncoding.default, forHTTPHeaderField: "Content-Encoding")
//        request.addValue(<#T##value: String##String#>, forHTTPHeaderField: <#T##String#>)
            // POSTするデータをBodyとして設定
//            let urlstr = "userid=" + "001873" + "&userimg=" + base64ImgStr
    //        request.httpBody = "userid=666666&username=true&distcode=8888".data(using: .utf8)
//            request.httpBody = urlstr.data(using: .utf8)!
        
       do{
        request.httpBody = try JSONSerialization.data(withJSONObject: params, options: .prettyPrinted)

            let session = URLSession.shared
            session.dataTask(with: request) { (data, response, error) in
                if error == nil, let data = data, let response = response as? HTTPURLResponse {
                    // HTTPヘッダの取得
                    print("Content-Type: \(response.allHeaderFields["Content-Type"] ?? "")")
                    // HTTPステータスコード
                    print("statusCode: \(response.statusCode)")
                    print(String(data: data, encoding: .utf8) ?? "")
                }
            }.resume()
        }catch{
            print("Error:\(error)")
            return
        }
        }

    func recoImage(img:UIImage) {
    //        let newimg = imageRotatedByDegrees(oldImage: img,deg: 180.0)
    //        let imageData:NSData = newimg.jpegData(compressionQuality: 0.5)! as NSData
            let image1 = img.resize(scale: 0.5)!
            
            let imageData:NSData = image1.toJpegData(.min)! as NSData
        
                let imageStr = Utils.base64UrlSafeEncoding(data: imageData as Data)
                       
                       
                       
                       let json: [String: Any] = ["paramSetId":"AUTH_1_N_M_NONE",
                                                  "queryImages":imageStr]

                       let jsonData = try? JSONSerialization.data(withJSONObject: json)

                       // create post request
                       let url2 = URL(string: "https://api.cloud.nec.com/neoface/f-face-image/v1/action/auth")
                       var request2 = URLRequest(url: url2!)
                       request2.httpMethod = "POST"
                       request2.addValue("application/json", forHTTPHeaderField: "Content-Type")
                       request2.addValue("l70729f43684e243309443593a69487f27", forHTTPHeaderField: "apikey")

                       // insert json data to the request
                       request2.httpBody = jsonData

                       var status200 = false
                       let task = URLSession.shared.dataTask(with: request2) { data, response, error in
                           print(data as Any)
                           guard let data = data, error == nil else {
                               print(error?.localizedDescription ?? "No data")
                               return
                           }
                           if let response = response as? HTTPURLResponse {
                               print("response.statusCode = \(response.statusCode)")
                               if response.statusCode == 200 {
                                   status200 = true
                               }
                           }
                           if status200 == true {
                            let responseJSON = try? JSONSerialization.jsonObject(with: data, options: [])
                            let faceJsond = try! JSONDecoder().decode(faceJson.self, from: data)
                            print(faceJsond.statusCode)
                            
                               if let responseJSON = responseJSON as? [String: Any] {
                                print(responseJSON["statusCode"] as Any)
//                                if  responseJSON["statusCode"] as! Int == 200 {
//                                    if let responsefaceMatches = responseJSON["faceMatches"] as? [String: Any] {
//                                        print(responsefaceMatches["matchUser"] as! String)
//                                    }
//                                }
                               }
                           }
                       }

                       task.resume()
        
           }

    
        func convertImageToBase64(_ image: UIImage) -> String {
            let imageData:NSData = image.jpegData(compressionQuality: 1.0)! as NSData
//            let imageData = image.jpegData(compressionQuality: 1.0)
//            let strBase64 = Utils.base64UrlSafeEncoding(data: imageData)
               let strBase64 = imageData.base64EncodedString(options: .lineLength64Characters)
//            let encodeString:String =
//                imageData.base64EncodedString(options: NSData.Base64EncodingOptions.lineLength64Characters)

               return strBase64
        }
    
    func convertBase64StringToImage (imageBase64String:String) -> UIImage?{
//        let imageData = Data.init(base64Encoded: imageBase64String, options: .init(rawValue: 0))
//        let image = UIImage(data: imageData!)!
//        return image
        let decodeBase64:NSData? =
            NSData(base64Encoded:imageBase64String, options: NSData.Base64DecodingOptions.ignoreUnknownCharacters)
         if let decodeSuccess = decodeBase64 {

                   //NSDataからUIImageを生成
            let img = UIImage(data: decodeSuccess as Data)

                   //結果を返却
                   return img
               }
        return nil
//        guard let imageData = Data(base64Encoded: imageBase64String) else { return nil }
//        return UIImage(data: imageData)
    }
    
    func getimg()  {
//        let url = URL(string: "http://192.168.10.6:3000/testing")
//                var request = URLRequest(url: url!)
//                // POSTを指定
//                request.httpMethod = "GET"
//                // POSTするデータをBodyとして設定
//                let urlstr = "userid=eq." + "001873"
//        //        request.httpBody = "userid=666666&username=true&distcode=8888".data(using: .utf8)
//                request.httpBody = urlstr.data(using: .utf8)!
//                let session = URLSession.shared
//                session.dataTask(with: request) { (data, response, error) in
//                    if error == nil, let data = data, let response = response as? HTTPURLResponse {
//                        // HTTPヘッダの取得
//                        print("Content-Type: \(response.allHeaderFields["Content-Type"] ?? "")")
//                        // HTTPステータスコード
//                        print("statusCode: \(response.statusCode)")
//                        print(String(data: data, encoding: .utf8) ?? "")
//                    }
//                }.resume()
        
//        let url = URL(string: "http://192.168.10.6:3000/testing?userid=eq.001872")!
//               var request  = URLRequest(url: url)
//               request.httpMethod = "GET"
////               let boundary = "Boundary-\(UUID().uuidString)"
////               request.setValue("multipart/form-data; boundary=\(boundary)", forHTTPHeaderField: "Content-Type")
//               let task = URLSession.shared.dataTask(with: request as URLRequest) {
//                   data, response, error in
//                   if error != nil {
//                       //print("error=\(error)")
//                       return
//                   }
//                   do {
//                       let json = try JSONSerialization.jsonObject(with: data!, options: []) as? NSDictionary
//                    print(json as Any)
//                   }catch
//                   {
//                       print(error)
//                   }
//               }
//               task.resume()
        
//        let url = NSURL(string: "http://192.168.10.6:3000/testing?userid=eq.001872")
//        let config = URLSessionConfiguration.default
//        let session = URLSession(configuration: config)
//        let req = URLRequest(url: url! as URL)
//
//        //NSURLSessionDownloadTask is retured from session.dataTaskWithRequest
//        let task = session.dataTask(with: req as URLRequest, completionHandler: {
//            (data, resp, err) in
//            print(resp?.url! as Any)
//            print(NSString(data: data!, encoding: String.Encoding.utf8.rawValue) as Any)
//        })
//        task.resume()
        
        
        let url = URL(string: "http://192.168.10.6:3000/testing?userid=eq.001872")!
        print(url)
               URLSession.shared.dataTask(with: url) { data, response, error in
                   DispatchQueue.main.async {
                       self.userimg = try! JSONDecoder().decode([Userimg].self, from: data!)
                    let imgdata = Utils.base64UrlSafeDecoding(base64String: self.userimg[0].userimg)
                    let img = UIImage(data: imgdata!)
//                    let img = self.convertBase64StringToImage(imageBase64String: self.userimg[0].userimg)
//                    print(img?.pngData())
                   }
               }.resume()
    }
    
}
//struct User: Decodable, Identifiable {
struct Mainlist: Decodable {
    
    var userid: String
    var username: String
    var lastoutflg: Int
    var distname: String
    var indate: String
    var outdate: String
    
    
}

struct Distlist: Decodable {
    var i: Int
    var distcode: String
    var distname: String
    
}

struct Userimg:Decodable{
    var userid : String
    var userimg : String
}


struct faceJson:Decodable{
    var  statusCode: Int
    var  faceMatches:[FaceMatches]?
}

struct FaceMatches:Decodable {
    var faceMatchIndex :Int?
    var userMatches:[UserMatches]?
}
struct UserMatches:Decodable  {
    var score : String?
    var matchUser:MatchUser?
}

struct MatchUser:Decodable {
    var userOId:Int?
    var userId:String?
    var userName:String?
    
}
