import AVFoundation
import UIKit

class MainViewController: UIViewController, CameraViewDelegate, RecognizeResponseDelegate {
    @IBOutlet weak var mNavigationItem: UINavigationItem!
    @IBOutlet weak var mCameraView: CameraView!
    @IBOutlet weak var mHintLabel: UILabel!
    var indicator: UIActivityIndicatorView!

    func notifyPermissionResult(result: Bool) {
        LOG_FN_BEGIN()

        let title = "カメラの起動に失敗"
        let message = "カメラの使用が許可されているか確認してください。"

        DispatchQueue.main.async {
            if result {
                if !self.startCamera() {
                    self.okDialog(title: title, message: message)
                }
            } else {
                self.okDialog(title: title, message: message)
            }
        }

        LOG_FN_END()
    }

    func notifyPreviewStart() {
        LOG_FN_BEGIN()

        guard let cameraView = mCameraView else {
            LOG_ERROR(message: "CameraView is nil.")
            return
        }

        if CameraView.CaptureSessionStatus.RUNNING == cameraView.getCurrentCameraStatus() {
            // Display Views
            showCameraView()
        }

        LOG_FN_END()
    }

    func notifyCaptureData(captureData: Data) {
        LOG_FN_BEGIN()

        // Hide CameraView and GuideView
        _ = stopCamera()

        indicator.startAnimating()
        Recognize(jpeg: captureData, delegate: self).request()

        LOG_FN_END()
    }

    func notifyError(errorReason: Int) {
        LOG_FN_BEGIN()
        LOG_FN_END()
    }

    func requestFaceData() {
        LOG_FN_BEGIN()

        guard let cameraView = mCameraView else {
            return
        }
        cameraView.permissionCheck()

        LOG_FN_END()
    }

    private func startCamera() -> Bool {
        guard let cameraView = mCameraView else {
            return false
        }

        if !cameraView.startCamera() {
            return false
        }

        mHintLabel.isHidden = false
        return true
    }

    private func stopCamera() -> Bool {
        guard let cameraView = mCameraView else {
            return false
        }

        if !cameraView.stopCamera() {
            return false
        }

        hideCameraView()

        mHintLabel.isHidden = true
        return true
    }

    @IBAction func shiftToNextCamera() {
        _ = stopCamera()
        var cameraID = Setting.getCameraID()
        cameraID = CameraView.shiftToNextCameraID(id: cameraID)
        Setting.setCameraID(id: cameraID)
        _ = startCamera()
    }

    private func createCameraView() {
        guard let cameraView = mCameraView else {
            LOG_ERROR(message: "CameraView is nil.")
            return
        }
        LOG_DEBUG(message: "self.view.frame : \(view.frame)")
        cameraView.setCameraViewDelegate(cameraViewDelegate: self)
    }

    private func showCameraView() {
        guard let cameraView = mCameraView else {
            LOG_ERROR(message: "CameraView is nil.")
            return
        }
        cameraView.isHidden = false
    }

    private func hideCameraView() {
        guard let cameraView = mCameraView else {
            LOG_ERROR(message: "CameraView is nil.")
            return
        }

        cameraView.isHidden = true
    }

    override func viewDidLoad() {
        super.viewDidLoad()

        Setting.setInitialDefault()
        indicator = addProgressIndicator()

        if UIScreen.main.bounds.width <= 370 {
            mNavigationItem.title = "NFC Sample"
        }

        createCameraView()
        guard mCameraView != nil else {
            LOG_ERROR(message: "Camera CANNOT Prepared.")
            return
        }
    }

    override func viewWillAppear(_ animated: Bool) {
        requestFaceData()
    }

    override func viewDidDisappear(_ animated: Bool) {
    }

    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        LOG_FN_BEGIN()

        if CameraView.CaptureSessionStatus.RUNNING == mCameraView.getCurrentCameraStatus()
            && mCameraView.isCameraCaptureReady() {
            mCameraView.capture()
        }

        LOG_FN_END()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }

    func recognizeResponseCB(recognizeResponse: RecognizeResponse) {
        LOG_FN_BEGIN()
        indicator.stopAnimating()

        if recognizeResponse.responce.userMatches.count > 0 {
            let resultViewController = storyboard?.instantiateViewController(withIdentifier: "authResult") as! AuthResultViewController
            resultViewController.result = recognizeResponse
            present(resultViewController, animated: false, completion: nil)
            return
        }

        var failReason = "エラーが発生しました"
        switch recognizeResponse.responce.status {
        case .FaceNotDetected:
            failReason = "顔を検出できませんでした"
        case .MultiFacesDetected:
            failReason = "複数の顔を検出しました"
        case .FaceCheckInvalid, .NotAvailableFeature:
            failReason = "顔画像が基準を満たしていません"
        case .LivenessNG:
            failReason = "なりすましを検出しました"
        default:
            break
        }
        okDialog(title: "顔認証に失敗しました", message: failReason)
        _ = startCamera()

        LOG_FN_END()
    }

    @IBAction func returnToMe(segue: UIStoryboardSegue) {}
}
