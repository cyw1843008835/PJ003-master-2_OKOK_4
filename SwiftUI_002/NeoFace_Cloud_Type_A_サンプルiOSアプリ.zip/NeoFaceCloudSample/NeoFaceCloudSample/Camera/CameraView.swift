import AVFoundation
import Foundation
import UIKit

protocol CameraViewDelegate: class {
    func notifyPermissionResult(result: Bool)
    func notifyPreviewStart()
    func notifyCaptureData(captureData: Data)
    func notifyError(errorReason: Int)
}

class CameraView: UIView, AVCapturePhotoCaptureDelegate {
    var mCameraViewDelegate: CameraViewDelegate?

    var mCaptureSession: AVCaptureSession?
    var mStillImageOutput: AVCapturePhotoOutput?

    private var mCaptureSessionStatus: CaptureSessionStatus = .INIT
    enum CaptureSessionStatus {
        case INIT
        case CREATED
        case RUNNING
        case STOP
    }

    override init(frame: CGRect) {
        super.init(frame: frame)
        LOG_DEBUG(message: "init with frame.")
    }

    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        LOG_DEBUG(message: "init with aDecoder.")
    }

    func setCameraViewDelegate(cameraViewDelegate: CameraViewDelegate) {
        mCameraViewDelegate = cameraViewDelegate
    }

    func permissionCheck() {
        guard let cameraViewDelegate = mCameraViewDelegate else {
            LOG_DEBUG(message: "CameraViewDelegate is not REGISTED.")
            return
        }

        let status = AVCaptureDevice.authorizationStatus(for: AVMediaType.video)
        switch status {
        case .notDetermined:
            LOG_DEBUG(message: "AVMediaTypeStatus : NOT DETERMINED.")
            AVCaptureDevice.requestAccess(for: AVMediaType.video, completionHandler: { (granted: Bool) in
                cameraViewDelegate.notifyPermissionResult(result: granted)
            })
        case .authorized:
            LOG_DEBUG(message: "AVMediaTypeStatus : AUTHORIZED.")
            cameraViewDelegate.notifyPermissionResult(result: true)
        case .restricted:
            LOG_DEBUG(message: "AVMediaTypeStatus : RESTRICTED.")
            fallthrough
        default:
            LOG_DEBUG(message: "AVMediaTypeStatus : DENIED.")
            cameraViewDelegate.notifyPermissionResult(result: false)
        }
    }

    func startCamera() -> Bool {
        var cameraID = Setting.getCameraID()

        if !createCaptureSession(cameraID: &cameraID) {
            return false
        }
        Setting.setCameraID(id: cameraID)
        setCurrentCameraPresets()

        if CaptureSessionStatus.CREATED != mCaptureSessionStatus {
            LOG_ERROR(message: "CaptureSession is not !CREATED!.")
            return false
        }

        guard let captureSession = mCaptureSession else {
            LOG_ERROR(message: "CaptureSession is nil.")
            return false
        }

        DispatchQueue.global().async {
            // Dispatch SubThread
            captureSession.startRunning()
            self.mCaptureSessionStatus = .RUNNING

            DispatchQueue.main.async {
                // Dispatch MainThread
                self.setCameraLayer()

                guard let cameraViewDelegate = self.mCameraViewDelegate else {
                    LOG_DEBUG(message: "CameraViewDelegate is not REGISTED.")
                    return
                }
                cameraViewDelegate.notifyPreviewStart()
            }
        }

        return true
    }

    func stopCamera() -> Bool {
        if CaptureSessionStatus.RUNNING != mCaptureSessionStatus {
            LOG_ERROR(message: "CaptureSession is not !RUNNING!.")
            return false
        }

        guard let captureSession = mCaptureSession else {
            LOG_ERROR(message: "CaptureSession is nil.")
            return false
        }

        captureSession.stopRunning()
        mCaptureSessionStatus = .STOP

        return true
    }

    func capture() {
        LOG_FN_BEGIN()

        let settings = AVCapturePhotoSettings()
        // 手ぶれ補正
        settings.isAutoStillImageStabilizationEnabled = true
        // 高解像度
        settings.isHighResolutionPhotoEnabled = false

        if CaptureSessionStatus.RUNNING != mCaptureSessionStatus {
            return
        }

        guard let captureSession = mCaptureSession else {
            LOG_ERROR(message: "captureSession is nil.")
            return
        }
        if !captureSession.isRunning {
            LOG_ERROR(message: "captureSession.isRunning is false.")
            return
        }

        guard let stillImageOutput = mStillImageOutput else {
            LOG_ERROR(message: "StillImageOutput is nil.")
            return
        }

        stillImageOutput.capturePhoto(with: settings, delegate: self)

        LOG_FN_END()
    }

    func getCurrentCameraStatus() -> CaptureSessionStatus {
        return mCaptureSessionStatus
    }

    func isCameraCaptureReady() -> Bool {
        guard let captureSession = mCaptureSession else {
            return false
        }

        return captureSession.isRunning ? true : false
    }

    @available(iOS 11.0, *)
    func photoOutput(_ output: AVCapturePhotoOutput, didFinishProcessingPhoto photo: AVCapturePhoto, error: Error?) {
        LOG_FN_BEGIN()

        let photoData = photo.fileDataRepresentation()

        notifyCaptureData(captureData: photoData)

        LOG_FN_END()
    }

    func photoOutput(_ captureOutput: AVCapturePhotoOutput,
                     didFinishProcessingPhoto photoSampleBuffer: CMSampleBuffer?,
                     previewPhoto previewPhotoSampleBuffer: CMSampleBuffer?,
                     resolvedSettings: AVCaptureResolvedPhotoSettings,
                     bracketSettings: AVCaptureBracketedStillImageSettings?,
                     error: Error?) {
        LOG_FN_BEGIN()

        var photoData: Data?
        if let photoSampleBuffer = photoSampleBuffer {
            if #available(iOS 11.0, *) {
                LOG_ERROR(message: "iOS 11 photoOutput is deplicated ...")
            } else {
                photoData = AVCapturePhotoOutput.jpegPhotoDataRepresentation(forJPEGSampleBuffer: photoSampleBuffer,
                                                                             previewPhotoSampleBuffer: previewPhotoSampleBuffer)
            }
            if nil == photoData {
                LOG_DEBUG(message: "Capture PhotoData is nil.")
            }
        }

        notifyCaptureData(captureData: photoData)
        LOG_FN_END()
    }

    private func notifyCaptureData(captureData: Data?) {
        LOG_FN_BEGIN()

        guard let cameraViewDelegate = mCameraViewDelegate,
            let data = captureData else {
            LOG_DEBUG(message: "CameraViewDelegate is not REGISTED.")
            return
        }
        cameraViewDelegate.notifyCaptureData(captureData: data)

        LOG_FN_END()
    }

    private func createCaptureSession(cameraID: inout String) -> Bool {
        mCaptureSession = AVCaptureSession()
        mStillImageOutput = AVCapturePhotoOutput()

        guard let captureSession = mCaptureSession,
            let stillImageOutput = mStillImageOutput else {
            LOG_ERROR(message: "CaptureSession or StillImageOutput is nil.")
            return false
        }

        setCurrentCameraPresets()
        let size = Setting.getCameraSize()
        var preset = CameraView.currentCameraPresets.first(where: { $0.rawValue.contains(size) })
        if preset == nil {
            preset = AVCaptureSession.Preset.vga640x480
            LOG_ERROR(message: "use preset vga640x480 instead of size:\(size)")
        }

        captureSession.sessionPreset = preset!

        var dev: AVCaptureDevice?
        if cameraID != "" {
            dev = getAVCaptureDevice(id: cameraID)
            if dev == nil {
                LOG_ERROR(message: "\(cameraID) is not exist.")
            }
        }
        if dev == nil {
            dev = getFrontAVCaptureDevice()
        }

        guard let captureDevice: AVCaptureDevice = dev else {
            LOG_ERROR(message: "AVCaptureDevice not found.")
            return false
        }
        cameraID = captureDevice.uniqueID

        guard let captureDeviceInput = try? AVCaptureDeviceInput(device: captureDevice) else {
            LOG_ERROR(message: "AVCaptureDeviceInput Error.")
            return false
        }

        if !captureSession.canAddInput(captureDeviceInput) {
            LOG_ERROR(message: "CaptureSession canAddInput is return !FALSE!.")
            return false
        }
        captureSession.addInput(captureDeviceInput)

        if !captureSession.canAddOutput(stillImageOutput) {
            LOG_ERROR(message: "CaptureSession canAddOutput is return !FALSE!.")
            return false
        }
        captureSession.addOutput(stillImageOutput)

        mCaptureSessionStatus = .CREATED

        return true
    }

    static func getCameraIDs() -> [String] {
        return getAVCaptureDevices().map { $0.uniqueID }
    }

    static func getAVCaptureDevices() -> [AVCaptureDevice] {
        var deviceTypes: [AVCaptureDevice.DeviceType] = [.builtInDualCamera, .builtInTelephotoCamera, .builtInWideAngleCamera]
        if #available(iOS 11.1, *) {
            deviceTypes.insert(.builtInTrueDepthCamera, at: 0)
        }
        return AVCaptureDevice.DiscoverySession(deviceTypes: deviceTypes,
                                                mediaType: AVMediaType.video,
                                                position: .unspecified).devices
    }

    static func shiftToNextCameraID(id: String) -> String {
        var ids = getCameraIDs()
        ids.append(ids[0])
        for i in 0 ..< (ids.count - 1) where ids[i] == id {
            return ids[i + 1]
        }
        return ""
    }

    private func getFrontAVCaptureDevice() -> AVCaptureDevice? {
        return CameraView.getAVCaptureDevices().first(where: { $0.position == AVCaptureDevice.Position.front })
    }

    private func getAVCaptureDevice(id: String) -> AVCaptureDevice? {
        return CameraView.getAVCaptureDevices().first(where: { $0.uniqueID == id })
    }

    private func setCameraLayer() {
        if CaptureSessionStatus.RUNNING != mCaptureSessionStatus {
            LOG_ERROR(message: "CaptureSessionStatus is not !RUNNING!.")
            return
        }

        guard let captureSession = mCaptureSession else {
            LOG_ERROR(message: "CaptureSession is nil.")
            return
        }

        let previewLayer: AVCaptureVideoPreviewLayer = AVCaptureVideoPreviewLayer(session: captureSession)
        previewLayer.videoGravity = AVLayerVideoGravity.resizeAspectFill

        guard let previewLayerConnection: AVCaptureConnection = previewLayer.connection else {
            LOG_ERROR(message: "CaptureConnection is nil.")
            return
        }
        previewLayerConnection.videoOrientation = AVCaptureVideoOrientation.portrait

        layer.addSublayer(previewLayer)
        previewLayer.position = CGPoint(x: frame.width / 2, y: frame.height / 2)
        previewLayer.bounds = frame
    }

    static var currentCameraPresets: [AVCaptureSession.Preset] = []

    func setCurrentCameraPresets() {
        let list: [AVCaptureSession.Preset] = [.cif352x288, .vga640x480, .iFrame960x540, .hd1280x720, .hd1920x1080, .hd4K3840x2160]

        CameraView.currentCameraPresets = list.filter { mCaptureSession!.canSetSessionPreset($0) }
    }
}
