import Foundation
import SwiftyJSON
import UIKit
import WebKit

protocol OidcAuthDelegate: class {
    func oidcCallBack(token: String)
    func oidcCanceled()
}

class OidcViewController: UIViewController, WKNavigationDelegate {
    let oidcRedirectScheme = "https"
    let oidcRedirectUri = "oidc-dummy-url.nec.com"
    let oidcRedirectPath = "/"
    let oidcAuthEndpoint = "https://iam.cloud.nec.com/oidc/authorize"
    let oidcIss = "https://iam.cloud.nec.com/oidc/"

    @IBOutlet weak var webView: WKWebView!
    var nonce: String = ""
    var oidcAuthDelegate: OidcAuthDelegate?

    func setDelegate(delegate: OidcAuthDelegate) {
        oidcAuthDelegate = delegate
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        startOidcAuth()
    }

    func startOidcAuth() {
        webView.navigationDelegate = self
        guard let tempNonce: String = getNonce() else {
            LOG_ERROR(message: "Failed to create nonce")
            return
        }
        nonce = tempNonce

        let redirect = "\(oidcRedirectScheme)://\(oidcRedirectUri)\(oidcRedirectPath)".addingPercentEncoding(withAllowedCharacters: CharacterSet.alphanumerics)!
        let uriStr = "\(oidcAuthEndpoint)?response_type=id_token+token&scope=openid+offline_access+profile&redirect_uri=\(redirect)&nonce=\(nonce)&client_id=\(Setting.getOidcClientID())"

        let url = URL(string: uriStr)!
        LOG_DEBUG(message: "access to \(uriStr)")

        let request = URLRequest(url: url)
        webView.load(request)
    }

    static func deleteCookie() {
        WKWebsiteDataStore.default().removeData(ofTypes: WKWebsiteDataStore.allWebsiteDataTypes(), modifiedSince: Date(timeIntervalSince1970: 0), completionHandler: {})
    }

    private func getNonce() -> String? {
        let count = 8
        let data = NSMutableData(length: count)!
        let err = SecRandomCopyBytes(kSecRandomDefault, count, data.mutableBytes)
        guard err == 0 else {
            return nil
        }

        return Utils.base64UrlSafeEncoding(data: data as Data, padding: false)
    }

    func doAfterSaveCookie(closure: @escaping () -> Void) {
        var first = true

        let firstClosure: () -> Void = {
            objc_sync_enter(first)
            let f = first
            first = false
            objc_sync_exit(first)
            if f {
                closure()
            }
        }

        webView.configuration.websiteDataStore.httpCookieStore.getAllCookies { _ in
            firstClosure()
        }

        DispatchQueue.main.asyncAfter(deadline: .now() + 10) {
            firstClosure()
        }
    }

    func webView(_ webView: WKWebView, didReceiveServerRedirectForProvisionalNavigation navigation: WKNavigation!) {
        LOG_DEBUG(message: "Redirect url: \(webView.url!)")

        if webView.url?.host == oidcRedirectUri {
            var accessToken = ""
            defer {
                doAfterSaveCookie(closure: { () -> Void in self.goBack(token: accessToken) })
            }
            guard let fragment: String = webView.url?.fragment else { return }
            accessToken = getAccessToken(fragment: fragment)
        }
    }

    func getAccessToken(fragment: String) -> String {
        let kvs = fragment.split(separator: "&").map { $0.split(separator: "=") }.map { (String($0[0]), String($0[1])) }
        let dict = Dictionary(uniqueKeysWithValues: kvs)

        LOG_DEBUG(message: "access_token:\(dict["access_token"] ?? "")")
        LOG_DEBUG(message: "id_token:\(dict["id_token"] ?? "")")
        LOG_DEBUG(message: "expires_in:\(dict["expires_in"] ?? "")")

        guard dict["access_token"] != nil else {
            LOG_DEBUG(message: "access_token is none")
            return ""
        }
        guard dict["id_token"] != nil else {
            LOG_DEBUG(message: "id_token is none")
            return ""
        }

        guard validate(idToken: dict["id_token"]!) else {
            LOG_ERROR(message: "token validate failed")
            return ""
        }

        return dict["access_token"]!
    }

    func hmacSha256(message: String, key: String) -> Data {
        var digest = [UInt8](repeating: 0, count: Int(CC_SHA256_DIGEST_LENGTH))
        CCHmac(CCHmacAlgorithm(kCCHmacAlgSHA256), key, key.count, message, message.count, &digest)
        return Data(bytes: digest)
    }

    func validate(idToken: String) -> Bool {
        // IDトークンをヘッダ、ペイロード、署名に分割
        let idTokenSplit = idToken.split(separator: ".").map { String($0) }
        let idTokenHeader = Utils.base64UrlSafeDecodeString(base64String: idTokenSplit[0])
        let idTokenPayload = Utils.base64UrlSafeDecodeString(base64String: idTokenSplit[1])
        let idTokenSignature = idTokenSplit[2]

        LOG_DEBUG(message: "id_token.header: " + idTokenHeader)
        LOG_DEBUG(message: "id_token.payload: " + idTokenPayload)
        LOG_DEBUG(message: "id_token.sign: " + idTokenSignature)

        // 署名の検証
        let oidcSecret = Setting.getOidcSecretKey()
        if oidcSecret == "" {
            LOG_DEBUG(message: "-- skip signature validation --")
        } else {
            let text = idTokenSplit[0] + "." + idTokenSplit[1]
            let digest = hmacSha256(message: text, key: oidcSecret)
            let signBase64 = Utils.base64UrlSafeEncoding(data: digest, padding: false)
            LOG_DEBUG(message: "validated sign: " + signBase64)
            if idTokenSignature == signBase64 {
                LOG_DEBUG(message: "signature validation OK")
            } else {
                return false
            }
        }

        // ペイロードの検証
        let payloadJson = JSON(parseJSON: idTokenPayload)
        guard let iss: String = payloadJson["iss"].string else {
            LOG_DEBUG(message: "iss is none")
            return false
        }
        LOG_DEBUG(message: "iss: " + iss)
        if iss == oidcIss {
            LOG_DEBUG(message: "iss validation OK")
        } else {
            LOG_DEBUG(message: "iss validation NG")
            return false
        }

        guard let aud: String = payloadJson["aud"].string else {
            LOG_DEBUG(message: "aud is none")
            return false
        }
        LOG_DEBUG(message: "aud: " + aud)
        if aud == Setting.getOidcClientID() {
            LOG_DEBUG(message: "aud validation OK")
        } else {
            LOG_DEBUG(message: "aud validation NG")
            return false
        }

        guard let payLoadNonce: String = payloadJson["nonce"].string else {
            LOG_DEBUG(message: "nonce is none")
            return false
        }
        LOG_DEBUG(message: "nonce: " + payLoadNonce)
        if payLoadNonce == nonce {
            LOG_DEBUG(message: "nonce validation OK")
        } else {
            LOG_DEBUG(message: "nonce validation NG")
            return false
        }

        let currentSec: Int = Int(Date().timeIntervalSince1970)
        LOG_DEBUG(message: "current time: " + String(currentSec))

        guard let iat: Int = payloadJson["iat"].int else {
            LOG_DEBUG(message: "iat is none")
            return false
        }
        LOG_DEBUG(message: "iat: " + String(iat))
        if iat >= currentSec - 600 {
            LOG_DEBUG(message: "iat validation OK")
        } else {
            LOG_DEBUG(message: "iat validation NG")
            return false
        }

        guard let exp: Int = payloadJson["exp"].int else {
            LOG_DEBUG(message: "exp is none")
            return false
        }
        if exp > currentSec {
            LOG_DEBUG(message: "exp validation OK")
        } else {
            LOG_DEBUG(message: "exp validation NG")
            return false
        }

        return true
    }

    func goBack(token: String) {
        dismiss(animated: false, completion: nil)
        oidcAuthDelegate?.oidcCallBack(token: token)
    }

    @IBAction func goBack() {
        dismiss(animated: false, completion: nil)
        oidcAuthDelegate?.oidcCanceled()
    }
}
