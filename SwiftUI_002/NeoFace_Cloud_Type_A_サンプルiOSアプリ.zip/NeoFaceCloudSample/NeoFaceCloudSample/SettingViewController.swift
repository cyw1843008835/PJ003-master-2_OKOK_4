import Eureka
import UIKit

class SettingViewController: FormViewController {
    let userDefault = UserDefaults.standard

    override func viewDidLoad() {
        super.viewDidLoad()

        form +++ Section("設定")
            <<< TextRow("TenantIDRowTag") {
                $0.title = "テナントID"
                $0.placeholder = "NeoFace CloudのテナントIDを入力してください"
                var rules = RuleSet<String>()
                rules.add(rule: RuleRequired())
                rules.add(rule: RuleMinLength(minLength: 8))
                rules.add(rule: RuleMaxLength(maxLength: 8))
                $0.add(ruleSet: rules)
                $0.validationOptions = .validatesOnBlur
                let temp: String = self.userDefault.string(forKey: "TenantID")!
                $0.value = temp
            }.onChange { row in
                self.userDefault.set(row.value, forKey: "TenantID")
            }.cellUpdate { cell, row in
                if !row.isValid {
                    cell.titleLabel?.textColor = .red
                }
            }
            <<< TextRow("AuthApiKeyRowTag") {
                $0.title = "認証用API-Key"
                $0.placeholder = "未設定"
                var rules = RuleSet<String>()
                rules.add(rule: RuleRequired())
                rules.add(rule: RuleMinLength(minLength: 34))
                rules.add(rule: RuleMaxLength(maxLength: 34))
                $0.add(ruleSet: rules)
                $0.validationOptions = .validatesOnBlur
                let temp: String = self.userDefault.string(forKey: "AuthApiKey")!
                $0.value = temp
            }.onChange { row in
                self.userDefault.set(row.value, forKey: "AuthApiKey")
            }.cellUpdate { cell, row in
                if !row.isValid {
                    cell.titleLabel?.textColor = .red
                }
            }
            <<< ActionSheetRow<String>("AuthThresholdRowTag") {
                let authThresholdList = Setting.authThresholdList!
                $0.title = "顔認証閾値"
                $0.selectorTitle = "顔認証閾値を選択"
                $0.options = authThresholdList.map { $0.threshold }
                $0.validationOptions = .validatesOnBlur
                let temp: String = self.userDefault.string(forKey: "AuthThreshold")!
                let val = authThresholdList.first(where: { $0.value == temp })!.threshold
                $0.value = val
            }.onChange { row in
                let paramID = Setting.authThresholdList.first(where: { $0.threshold == row.value })!.value
                self.userDefault.set(paramID, forKey: "AuthThreshold")
            }
            <<< SwitchRow("livenessRowTag") {
                $0.title = "ライブネス検知"
                let temp: Bool = self.userDefault.bool(forKey: "Liveness")
                $0.value = temp
            }.onChange { row in
                self.userDefault.set(row.value, forKey: "Liveness")
            }
            <<< SwitchRow("displayListRowTag") {
                $0.title = "顔認証された人以外の候補の表示"
                let temp: Bool = self.userDefault.bool(forKey: "DispalyList")
                $0.value = temp
            }.onChange { row in
                self.userDefault.set(row.value, forKey: "DispalyList")
            }

        form +++ Section("送信画像設定")
            <<< PickerInlineRow<String>("cameraSizeRowTag") {
                $0.title = "カメラ解像度"
                $0.options = CameraView.currentCameraPresets.map { Utils.regexReplace(str: $0.rawValue, pattern: "^.[a-zA-Z]*", with: "") }
                let temp: String = self.userDefault.string(forKey: "CameraSize") ?? "640x480"
                $0.value = temp
            }.onChange { row in
                self.userDefault.set(row.value, forKey: "CameraSize")
            }
            <<< SwitchRow("snipFaceRowTag") {
                $0.title = "顔部分のみを送信"
                let temp: Bool = self.userDefault.bool(forKey: "SnipFace")
                $0.value = temp
            }.onChange { row in
                self.userDefault.set(row.value, forKey: "SnipFace")
            }
            <<< SliderRow("JpegQualityRowTag") {
                $0.title = "JPEG品質"
                $0.steps = 99
                $0.cell.slider.maximumValue = 100
                $0.cell.slider.minimumValue = 1
                $0.displayValueFor = {
                    "\(Int($0 ?? 0))"
                }
                let temp: Int = self.userDefault.integer(forKey: "JpegQuality")
                $0.value = Float(temp)
            }.onChange { row in
                self.userDefault.set(Int(row.value!), forKey: "JpegQuality")
            }
            <<< SwitchRow("resizeEnableRowTag") {
                $0.title = "画像リサイズ"
                let temp: Bool = self.userDefault.bool(forKey: "ResizeEnable")
                $0.value = temp
            }.onChange { row in
                self.userDefault.set(row.value, forKey: "ResizeEnable")
            }
            <<< SliderRow("resizeRateRowTag") {
                $0.hidden = Condition.function(["resizeEnableRowTag"], { form in
                    !((form.rowBy(tag: "resizeEnableRowTag") as? SwitchRow)?.value ?? false)
                })
                $0.title = "画像リサイズ倍率"
                $0.steps = 29
                $0.cell.slider.maximumValue = 3
                $0.cell.slider.minimumValue = 0.1
                let temp: Float = self.userDefault.float(forKey: "ResizeRate")
                $0.value = temp
            }.onChange { row in
                self.userDefault.set(row.value, forKey: "ResizeRate")
            }
        form +++ Section("OpenID Connect設定　(顔登録時に設定必要)")
            <<< TextRow("oidcClientIDRowTag") {
                $0.title = "クライアントID"
                $0.placeholder = "OpenID ConnectのクライアントIDを入力します"
                var rules = RuleSet<String>()
                rules.add(rule: RuleRequired())
                $0.add(ruleSet: rules)
                $0.validationOptions = .validatesOnBlur
                let temp: String = self.userDefault.string(forKey: "OidcClientID")!
                $0.value = temp
            }.onChange { row in
                self.userDefault.set(row.value, forKey: "OidcClientID")
            }.cellUpdate { cell, row in
                if !row.isValid {
                    cell.titleLabel?.textColor = .red
                }
            }

            <<< TextRow("oidcSecretKeyRowTag") {
                $0.title = "クライアントシークレット"
                $0.placeholder = "OpenID Connectのクライアントシークレットを入力します(オプション)"
                $0.validationOptions = .validatesOnBlur
                let temp: String = self.userDefault.string(forKey: "OidcSecretKey")!
                $0.value = temp
            }.onChange { row in
                self.userDefault.set(row.value, forKey: "OidcSecretKey")
            }.cellUpdate { cell, row in
                if !row.isValid {
                    cell.titleLabel?.textColor = .red
                }
            }

            <<< ButtonRow("clearLoginButtonTag") {
                $0.title = "NeoFace Cloudポータルのログイン状態をクリア"
            }.onCellSelection { _, _ in
                OidcViewController.deleteCookie()
                self.okDialog(title: "NeoFace Cloudポータルのログイン状態をクリアしました")
            }
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}
