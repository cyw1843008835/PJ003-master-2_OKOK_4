#ifndef NFCSample_Bridging_Header_h
#define NFCSample_Bridging_Header_h

#import <CommonCrypto/CommonCrypto.h>

#endif /* NFCSample_Bridging_Header_h */
