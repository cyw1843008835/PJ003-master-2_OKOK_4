import UIKit

class AuthResultViewController: UIViewController {
    @IBOutlet weak var imageView: UIImageView!
    @IBOutlet weak var resultLabel: UILabel!
    @IBOutlet weak var userNameLabel: UILabel!
    @IBOutlet weak var scoreLabel: UILabel!
    @IBOutlet weak var usersLabel: UILabel!

    var result: RecognizeResponse!

    override func viewDidLoad() {
        super.viewDidLoad()

        let res = result.responce!

        imageView.image = UIImage(data: result.jpegData)?.snip(rect: res.headRect)
        if res.status == ResultStatus.Success {
            resultLabel.text = "認証結果:成功"
            userNameLabel.text = res.userMatches[0].userName
            scoreLabel.text = "score=\(res.userMatches[0].score)"
        } else {
            resultLabel.text = "認証結果:失敗"
            userNameLabel.text = ""
            scoreLabel.text = ""
        }

        if Setting.getDisplayList() {
            usersLabel.text = "候補リスト:\n" + res.userMatches.map { "\($0.userName),score=\($0.score)" }.joined(separator: "\n")
        } else {
            usersLabel.text = ""
        }
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }

    @IBAction func goBack(_ sender: Any) {
        dismiss(animated: false, completion: nil)
    }

    @IBAction func goToRegister(_ sender: Any) {
        LOG_FN_BEGIN()

        let faceRegisterViewController = storyboard?.instantiateViewController(withIdentifier: "faceRegister") as! FaceRegsisterViewController
        faceRegisterViewController.jpegData = imageView.image?.toJpegData()
        present(faceRegisterViewController, animated: false, completion: nil)

        LOG_FN_END()
    }
}
