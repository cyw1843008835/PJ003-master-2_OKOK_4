import UIKit

class FaceRegsisterViewController: UIViewController, UITextFieldDelegate, UserAndFaceRegisterResponseDelegate, OidcAuthDelegate {
    @IBOutlet weak var imageView: UIImageView!
    @IBOutlet weak var userIDLabel: UILabel!
    @IBOutlet weak var userNameLabel: UILabel!
    @IBOutlet weak var userIDField: UITextField!
    @IBOutlet weak var userNameField: UITextField!

    var jpegData: Data!
    var indicator: UIActivityIndicatorView!

    override func viewDidLoad() {
        super.viewDidLoad()

        userIDField.returnKeyType = .next
        userNameField.returnKeyType = .done
        userIDField.delegate = self
        userNameField.delegate = self

        imageView.image = UIImage(data: jpegData)
        indicator = addProgressIndicator()
    }

    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        // 背景がタッチされたらキーボードを閉じる
        if userIDField.isFirstResponder {
            userIDField.resignFirstResponder()
        }
        if userNameField.isFirstResponder {
            userNameField.resignFirstResponder()
        }
    }

    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        if textField == userIDField {
            userNameField.becomeFirstResponder()
        } else {
            textField.resignFirstResponder()
        }

        return true
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }

    @IBAction func goBack2(_ sender: Any) {
        presentingViewController?.presentingViewController?.dismiss(animated: false, completion: nil)
    }

    @IBAction func register(_ sender: Any) {
        guard let userID: String = userIDField.text, userID != "" else {
            okDialog(title: "\(userIDLabel.text!)が未入力です")
            return
        }

        guard let userName: String = userNameField.text, userName != "" else {
            okDialog(title: "\(userNameLabel.text!)が未入力です")
            return
        }

        guard Setting.getOidcClientID() != "" else {
            okDialog(title: "OpenID Connect Client IDが未設定です")
            return
        }

        let oidcViewController = storyboard?.instantiateViewController(withIdentifier: "oidcAuth") as! OidcViewController
        oidcViewController.setDelegate(delegate: self)
        present(oidcViewController, animated: false, completion: nil)
    }

    func oidcCallBack(token: String) {
        guard token != "" else {
            okDialog(title: "Open ID Connect認証に失敗しました")
            return
        }

        indicator.startAnimating()
        Setting.setAccessToken(token: token)
        LOG_DEBUG(message: "token\(Setting.getAccessToken())")
        UserAndFaceRegister(userAndFaceRegisterResponseDelegate: self).request(userID: userIDField.text!, userName: userNameField.text!, jpegData: jpegData)
    }

    func oidcCanceled() {
        okDialog(title: "Open ID Connect認証をキャンセルしました")
    }

    func userAndFaceRegisterResponseCB(userAndFaceRegisterResult: UserAndFaceRegisterResult) {
        indicator.stopAnimating()

        var failReason = "エラーが発生しました"
        switch userAndFaceRegisterResult.status {
        case .Success:
            let alert: UIAlertController = UIAlertController(title: "登録に成功しました",
                                                             message: nil,
                                                             preferredStyle: UIAlertController.Style.alert)
            let defaultAction: UIAlertAction = UIAlertAction(title: "OK",
                                                             style: UIAlertAction.Style.default,
                                                             handler: { (_: UIAlertAction!) -> Void in self.goBack2(self)
            })
            alert.addAction(defaultAction)
            present(alert, animated: true)
        case .NetworkError:
            failReason = "ネットワークエラーが発生しました"
        case .Conflict:
            failReason = "IDが重複しています"
        case .FaceNotDetected:
            failReason = "顔を検出できませんでした"
        case .MultiFacesDetected:
            failReason = "複数の顔を検出しました"
        case .FaceCheckInvalid, .NotAvailableFeature:
            failReason = "顔画像が基準を満たしていません"
        default:
            break
        }
        okDialog(title: "登録に失敗しました", message: failReason)
    }
}
