import Alamofire
import Foundation
import SwiftyJSON

protocol UserFaceRegisterResponseDelegate: class {
    func userFaceRegisterResponseCB(userFaceRegisterResult: UserFaceRegisterResult)
}

class FaceRegister {
    private var mUserFaceRegisterResponseDelegate: UserFaceRegisterResponseDelegate?

    init(userFaceRegisterResponseDelegate: UserFaceRegisterResponseDelegate? = nil) {
        LOG_UI_FN_BEGIN()

        mUserFaceRegisterResponseDelegate = userFaceRegisterResponseDelegate

        LOG_UI_FN_END()
    }

    func request(userOID: Int, jpeg: String) -> Bool {
        LOG_UI_FN_BEGIN()

        let headers: HTTPHeaders = [
            "Content-Type": "application/json",
            "X-NECCP-Tenant-ID": Setting.GetTenantID(),
            "apikey": Setting.GetAuthApiKey()
        ]
        let parameters: [String: Any] = [
            "faceImage": jpeg,
            "faceIndex": 0,
            "faceState": "enabled"
        ]

        Alamofire.request(RestConstants.ManageUri + "users/\(userOID)/face/",
                          method: .post,
                          parameters: parameters,
                          encoding: JSONEncoding.default,
                          headers: headers)
            .responseString { (response: DataResponse<String>) in
                LOG_UI(message: "responseString : \(response)")

                var result = UserFaceRegisterResult()
                guard let userFaceRegisterResponseDelegate = self.mUserFaceRegisterResponseDelegate else {
                    return
                }
                defer {
                    userFaceRegisterResponseDelegate.userFaceRegisterResponseCB(userFaceRegisterResult: result)
                }

                if response.result.isSuccess {
                    result = UserFaceRegisterResult(httpStatusCode: response.response!.statusCode)
                } else {
                    // 全てネットワークエラーとして扱う
                    result = UserFaceRegisterResult(resultStatus: .NetworkError)
                }
            }

        LOG_UI_FN_END()
        return true
    }
}

class UserFaceRegisterResult {
    private(set) var status: ResultStatus

    init(resultStatus: ResultStatus = .Failed) {
        status = resultStatus
    }

    init(httpStatusCode: Int) {
        status = .Failed
        switch httpStatusCode {
        case 201:
            status = .Success
        case 434:
            status = .FaceNotDetected
        case 435:
            status = .MultiFacesDetected
        case 436:
            status = .FaceCheckInvalid
        case 443:
            status = .NotAvailableFeature
        default:
            break
        }
    }
}
