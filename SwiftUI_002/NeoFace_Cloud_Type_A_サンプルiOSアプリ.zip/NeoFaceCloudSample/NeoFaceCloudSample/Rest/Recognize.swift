import Foundation
import UIKit

protocol RecognizeResponseDelegate: class {
    func recognizeResponseCB(recognizeResponse: RecognizeResponse)
}

class RecognizeResponse {
    var jpegData: Data!
    var responce: FaceAuthResult!
    init(res: FaceAuthResult, jpeg: Data) {
        jpegData = jpeg
        responce = res
    }
}

class Recognize: FaceAuthResponseDelegate {
    var imageForAuth: ImageForAuth
    var recognizeDelegate: RecognizeResponseDelegate!

    init(jpeg: Data, delegate: RecognizeResponseDelegate) {
        imageForAuth = ImageForAuth(data: jpeg)
        recognizeDelegate = delegate
    }

    func request() {
        LOG_FN_BEGIN()

        let jpegStr = Utils.base64UrlSafeEncoding(data: imageForAuth.jpegData)
        LOG_DEBUG(message: "jpegStr data lenght:\(jpegStr.count)")
        FaceAuth(faceAuthResponseDelegate: self).request(jpgBase64String: jpegStr)

        LOG_FN_END()
    }

    func faceAuthResponseCB(faceAuthResult: FaceAuthResult) {
        LOG_FN_BEGIN()

        let res = RecognizeResponse(res: faceAuthResult, jpeg: imageForAuth.jpegData!)
        recognizeDelegate.recognizeResponseCB(recognizeResponse: res)

        LOG_FN_END()
    }
}
