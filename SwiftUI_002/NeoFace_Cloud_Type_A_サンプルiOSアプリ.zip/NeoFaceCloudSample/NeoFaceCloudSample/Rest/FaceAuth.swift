import Alamofire
import Foundation
import SwiftyJSON
import UIKit

protocol FaceAuthResponseDelegate: class {
    func faceAuthResponseCB(faceAuthResult: FaceAuthResult)
}

class FaceAuth {
    private var mFaceAuthResponseDelegate: FaceAuthResponseDelegate?

    init(faceAuthResponseDelegate: FaceAuthResponseDelegate? = nil) {
        LOG_FN_BEGIN()

        mFaceAuthResponseDelegate = faceAuthResponseDelegate

        LOG_FN_END()
    }

    func request(jpgBase64String: String) {
        LOG_FN_BEGIN()

        let headers: HTTPHeaders = [
            RequestHeaderContentType: RequestHeaderTypeJson,
            RequestHeaderApiKeyName: Setting.getAuthApiKey()
        ]
        let parameters: [String: Any] = [
            ParamSetID: Setting.getAuthParam(),
            QueryImages: jpgBase64String
        ]

        Alamofire.request(RestConstants.AuthUri,
                          method: .post,
                          parameters: parameters,
                          encoding: JSONEncoding.default,
                          headers: headers)
            .responseString { (response: DataResponse<String>) in
                LOG_DEBUG(message: "responseString : \(response)")
            }
            .responseJSON { (response: DataResponse<Any>) in
                var result = FaceAuthResult()
                guard let faceAuthResponseDelegate = self.mFaceAuthResponseDelegate else {
                    return
                }
                defer {
                    faceAuthResponseDelegate.faceAuthResponseCB(faceAuthResult: result)
                }

                if response.result.isSuccess {
                    guard let responseValue = response.result.value else { return }
                    result = FaceAuthResult(httpStatusCode: response.response!.statusCode, response: responseValue as? NSDictionary)
                } else {
                    // 全てネットワークエラーとして扱う
                    result = FaceAuthResult(resultStatus: .NetworkError)
                }
            }

        LOG_FN_END()
    }
}

class FaceAuthResult {
    private(set) var status = ResultStatus.Failed
    private(set) var headRect = CGRect.zero
    private(set) var userMatches: [(userName: String, score: Float)] = []

    init(resultStatus: ResultStatus = .Failed) {
        status = resultStatus
    }

    init(httpStatusCode: Int, response: NSDictionary? = nil) {
        guard httpStatusCode == 200 else {
            return
        }
        guard let res: NSDictionary = response else {
            return
        }
        let json: JSON = JSON(res)

        switch json["statusCode"].intValue {
        case 200:
            status = .Success
        case 404:
            status = .IDUnregistered
        case 424:
            status = .FaceUnregistered
        case 434:
            status = .FaceNotDetected
        case 435:
            status = .MultiFacesDetected
        case 436:
            let faceMatches: JSON = json["faceMatches"]
            if faceMatches.count > 0 {
                let faceInfoCheck: JSON = faceMatches[0]["faceInfoCheck"]
                let attributeCheck: JSON = faceInfoCheck["attributeCheck"]
                let faceLivenessScoreCheck: JSON = attributeCheck["faceLivenessScoreCheck"]
                if faceLivenessScoreCheck.string == "NG" {
                    status = .LivenessNG
                    break
                }
            }
            status = .FaceCheckInvalid
        case 443:
            status = .NotAvailableFeature
        case 444:
            status = .NotApplicable
        case 445:
            status = .NotMatched
        default:
            break
        }

        LOG_DEBUG(message: "status: \(status)")
        if [ResultStatus.Success, ResultStatus.NotApplicable, ResultStatus.NotMatched].contains(status) {
            userMatches = getFaceAuthUserNameAndScore(json: json)

            let rect = json["faceMatches"][0]["faceInfo"]["headRect"].arrayValue.map { $0.intValue }
            headRect = CGRect(x: rect[0], y: rect[1], width: rect[2] - rect[0], height: rect[3] - rect[1])
        }
    }

    private func getFaceAuthUserNameAndScore(json: JSON) -> [(userName: String, score: Float)] {
        LOG_FN_BEGIN()
        var userNameAndScore: [(userName: String, score: Float)] = []

        let faceMatches: JSON = json["faceMatches"]
        faceMatches.forEach { _, faceMatches in
            let userMatches: JSON = faceMatches["userMatches"]
            userMatches.forEach({ _, userMatches in
                guard let userName: String = userMatches["matchUser"]["userName"].string,
                    let score: String = userMatches["score"].string else {
                    LOG_ERROR(message: "userName or score is nil...")
                    return
                }

                userNameAndScore.append((userName: userName, score: NSString(string: score).floatValue))
            })
        }

        LOG_FN_END()
        return userNameAndScore
    }
}
