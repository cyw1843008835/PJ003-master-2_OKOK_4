import Alamofire
import Foundation
import SwiftyJSON

protocol UserRegisterResponseDelegate: class {
    func userRegisterResponseCB(userRegisterResult: UserRegisterResult)
}

class UserRegister {
    private var mUserRegisterResponseDelegate: UserRegisterResponseDelegate?

    init(userRegisterResponseDelegate: UserRegisterResponseDelegate? = nil) {
        LOG_FN_BEGIN()

        mUserRegisterResponseDelegate = userRegisterResponseDelegate

        LOG_FN_END()
    }

    func request(userId: String, userName: String) {
        LOG_FN_BEGIN()

        let headers: HTTPHeaders = [
            RequestHeaderContentType: RequestHeaderTypeJson,
            RequestHeaderTenantID: Setting.getTenantID(),
            RequestHeaderAuthorization: "Bearer \(Setting.getAccessToken())"
        ]
        let parameters: [String: Any] = [
            "userId": userId,
            "userName": userName,
            "userState": "enabled"
        ]

        Alamofire.request(RestConstants.ManageUri + "users",
                          method: .post,
                          parameters: parameters,
                          encoding: JSONEncoding.default,
                          headers: headers)
            .responseString { (response: DataResponse<String>) in
                LOG_DEBUG(message: "responseString : \(response)")
            }
            .responseJSON { (response: DataResponse<Any>) in
                var result = UserRegisterResult()
                guard let userRegisterResponseDelegate = self.mUserRegisterResponseDelegate else {
                    return
                }
                defer {
                    userRegisterResponseDelegate.userRegisterResponseCB(userRegisterResult: result)
                }

                if response.result.isSuccess {
                    guard let responseValue = response.result.value else { return }
                    result = UserRegisterResult(httpStatusCode: response.response!.statusCode, response: responseValue as? NSDictionary)
                } else {
                    // 全てネットワークエラーとして扱う
                    result = UserRegisterResult(resultStatus: .NetworkError)
                }
            }

        LOG_FN_END()
    }
}

class UserRegisterResult {
    private(set) var status = ResultStatus.Failed
    private(set) var userOID = -1

    init(resultStatus: ResultStatus = .Failed) {
        status = resultStatus
    }

    init(httpStatusCode: Int, response: NSDictionary? = nil) {
        switch httpStatusCode {
        case 201:
            guard let res: NSDictionary = response else {
                return
            }
            let json: JSON = JSON(res)
            guard let oid = json["userOId"].int else {
                return
            }
            userOID = oid
            status = .Success
        case 409:
            status = .Conflict
        default:
            break
        }
    }
}
