import Alamofire
import Foundation
import SwiftyJSON

protocol FaceRegisterResponseDelegate: class {
    func faceRegisterResponseCB(faceRegisterResult: FaceRegisterResult)
}

class FaceRegister {
    private var mfaceRegisterResponseDelegate: FaceRegisterResponseDelegate?

    init(faceRegisterResponseDelegate: FaceRegisterResponseDelegate? = nil) {
        LOG_FN_BEGIN()

        mfaceRegisterResponseDelegate = faceRegisterResponseDelegate

        LOG_FN_END()
    }

    func request(userOID: Int, jpeg: String) {
        LOG_FN_BEGIN()

        let headers: HTTPHeaders = [
            RequestHeaderContentType: RequestHeaderTypeJson,
            RequestHeaderTenantID: Setting.getTenantID(),
            RequestHeaderAuthorization: "Bearer \(Setting.getAccessToken())"
        ]
        let parameters: [String: Any] = [
            "faceImage": jpeg,
            "faceIndex": 0,
            "faceState": "enabled"
        ]

        Alamofire.request(RestConstants.ManageUri + "users/\(userOID)/faces",
                          method: .post,
                          parameters: parameters,
                          encoding: JSONEncoding.default,
                          headers: headers)
            .responseString { (response: DataResponse<String>) in
                LOG_DEBUG(message: "responseString : \(response)")

                var result = FaceRegisterResult()
                guard let userFaceRegisterResponseDelegate = self.mfaceRegisterResponseDelegate else {
                    return
                }
                defer {
                    userFaceRegisterResponseDelegate.faceRegisterResponseCB(faceRegisterResult: result)
                }

                if response.result.isSuccess {
                    result = FaceRegisterResult(httpStatusCode: response.response!.statusCode)
                } else {
                    // 全てネットワークエラーとして扱う
                    result = FaceRegisterResult(resultStatus: .NetworkError)
                }
            }

        LOG_FN_END()
    }
}

class FaceRegisterResult {
    private(set) var status = ResultStatus.Failed

    init(resultStatus: ResultStatus = .Failed) {
        status = resultStatus
    }

    init(httpStatusCode: Int) {
        switch httpStatusCode {
        case 201:
            status = .Success
        case 434:
            status = .FaceNotDetected
        case 435:
            status = .MultiFacesDetected
        case 436:
            status = .FaceCheckInvalid
        case 443:
            status = .NotAvailableFeature
        default:
            break
        }
    }
}
