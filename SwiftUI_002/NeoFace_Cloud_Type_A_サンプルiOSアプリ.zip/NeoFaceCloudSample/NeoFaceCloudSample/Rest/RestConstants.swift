import Foundation

// swiftlint:disable identifier_name

class RestConstants {
    static let ManageUri: String = "https://api.cloud.nec.com/neoface/v1/"
    static let AuthUri: String = "https://api.cloud.nec.com/neoface/f-face-image/v1/action/auth"
}

let RequestHeaderContentType: String = "Content-Type"
let RequestHeaderTypeJson: String = "application/json"
let RequestHeaderTenantID: String = "X-NECCP-Tenant-ID"
let RequestHeaderAuthorization: String = "Authorization"
let RequestHeaderApiKeyName: String = "apikey"

let ParamSetID: String = "paramSetId"
let QueryImages: String = "queryImages"

public enum ResultStatus {
    case Success
    case Failed
    case NetworkError
    case Conflict
    case FaceNotDetected
    case MultiFacesDetected
    case IDUnregistered
    case FaceUnregistered
    case FaceCheckInvalid
    case NotAvailableFeature
    case NotApplicable
    case NotMatched
    case LivenessNG
}
