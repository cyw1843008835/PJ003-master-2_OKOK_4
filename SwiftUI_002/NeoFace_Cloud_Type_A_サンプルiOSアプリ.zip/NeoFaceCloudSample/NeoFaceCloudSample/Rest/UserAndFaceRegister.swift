import Alamofire
import Foundation
import SwiftyJSON

protocol UserAndFaceRegisterResponseDelegate: class {
    func userAndFaceRegisterResponseCB(userAndFaceRegisterResult: UserAndFaceRegisterResult)
}

class UserAndFaceRegister: UserRegisterResponseDelegate, FaceRegisterResponseDelegate {
    private var mUserAndFaceRegisterResponseDelegate: UserAndFaceRegisterResponseDelegate?
    private var mUserOID: Int?
    private var mJpegData: Data?

    init(userAndFaceRegisterResponseDelegate: UserAndFaceRegisterResponseDelegate? = nil) {
        LOG_FN_BEGIN()

        mUserAndFaceRegisterResponseDelegate = userAndFaceRegisterResponseDelegate

        LOG_FN_END()
    }

    func request(userID: String, userName: String, jpegData: Data) {
        LOG_FN_BEGIN()

        mJpegData = jpegData
        UserRegister(userRegisterResponseDelegate: self).request(userId: userID, userName: userName)

        LOG_FN_END()
    }

    func userRegisterResponseCB(userRegisterResult: UserRegisterResult) {
        switch userRegisterResult.status {
        case .Success:
            mUserOID = userRegisterResult.userOID
            let jpegStr = Utils.base64UrlSafeEncoding(data: mJpegData)
            FaceRegister(faceRegisterResponseDelegate: self).request(userOID: mUserOID!, jpeg: jpegStr)
        default:
            guard let delegate: UserAndFaceRegisterResponseDelegate = mUserAndFaceRegisterResponseDelegate else { return }
            let result = UserAndFaceRegisterResult(resultStatus: userRegisterResult.status)
            delegate.userAndFaceRegisterResponseCB(userAndFaceRegisterResult: result)
        }
    }

    func faceRegisterResponseCB(faceRegisterResult: FaceRegisterResult) {
        guard let delegate: UserAndFaceRegisterResponseDelegate = mUserAndFaceRegisterResponseDelegate else { return }
        let result = UserAndFaceRegisterResult(resultStatus: faceRegisterResult.status)

        switch faceRegisterResult.status {
        case .Success:
            break
        default:
            // 顔登録に失敗した場合は、顔認証対象者を削除する
            UserUnregister().request(userOID: mUserOID!)
        }

        delegate.userAndFaceRegisterResponseCB(userAndFaceRegisterResult: result)
    }
}

class UserAndFaceRegisterResult {
    private(set) var status: ResultStatus

    init(resultStatus: ResultStatus = .Failed) {
        status = resultStatus
    }
}
