import Alamofire
import Foundation
import SwiftyJSON

protocol UserUnregisterResponseDelegate: class {
    func userUnregisterResponseCB(userUnregisterResult: UserUnregisterResult)
}

class UserUnregister {
    private var mUserUnregisterResponseDelegate: UserUnregisterResponseDelegate?

    init(userUnregisterResponseDelegate: UserUnregisterResponseDelegate? = nil) {
        LOG_FN_BEGIN()

        mUserUnregisterResponseDelegate = userUnregisterResponseDelegate

        LOG_FN_END()
    }

    func request(userOID: Int) {
        LOG_FN_BEGIN()

        let headers: HTTPHeaders = [
            RequestHeaderContentType: RequestHeaderTypeJson,
            RequestHeaderTenantID: Setting.getTenantID(),
            RequestHeaderAuthorization: "Bearer \(Setting.getAccessToken())"
        ]

        Alamofire.request(RestConstants.ManageUri + "users/" + String(userOID),
                          method: .delete,
                          encoding: JSONEncoding.default,
                          headers: headers)
            .responseString { (response: DataResponse<String>) in
                LOG_DEBUG(message: "responseString : \(response)")

                var result = UserUnregisterResult()
                guard let userUnregisterResponseDelegate = self.mUserUnregisterResponseDelegate else {
                    return
                }
                defer {
                    userUnregisterResponseDelegate.userUnregisterResponseCB(userUnregisterResult: result)
                }

                if response.result.isSuccess {
                    result = UserUnregisterResult(httpStatusCode: response.response!.statusCode)
                } else {
                    // 全てネットワークエラーとして扱う
                    result = UserUnregisterResult(resultStatus: .NetworkError)
                }
            }

        LOG_FN_END()
    }
}

class UserUnregisterResult {
    private(set) var status = ResultStatus.Failed

    init(resultStatus: ResultStatus = .Failed) {
        status = resultStatus
    }

    init(httpStatusCode: Int) {
        switch httpStatusCode {
        case 200:
            status = .Success
        default:
            break
        }
    }
}
